﻿function amaf_insertHTML(html) {
    alert('editor not supported');
};